1. Unzip files to a folder
2. Navigate to that folder in a terminal (use command `cd "YOUR_PATH_WHERE_YOU_UNZIPPED"`)
3. Assuming Docker is installed without issues, run 
`docker compose up --build`

This will up the entire stack and will give you a running process in the terminal. 
Wait for 30 seconds for entire stack to be up and running. The terminal will not stop, and its not an error. 
After 30 seconds, you can proceed executing commands in a different terminal


4. Now to test the kafka producer, run
`docker compose run --rm spark-runner python3 /app/scripts/test_kafka_producer.py`

This will check connection to kafka and emit 10 test messages to the topic test_topic


5. To test the consumer, run 

`docker compose run --rm spark-runner /opt/spark/bin/spark-submit --packages org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.1 /app/scripts/test_kafka_consumer.py`

This will allow spark to read from kafka topic. Note the jar we're passing in the above command, it allows spark to stream kafka topic. Without this package, it won't work. 


6. To test the postgres connection, run:
`docker compose run --rm spark-runner python3 /app/scripts/test_postgres_connection.py`

This will read from the orders table and output it to console. 



If all above commands run without errors, you've tested successfully the following:
- Kafka connection
- Kafka producer writing to topic
- Kafka / Spark connection (using jar we passed in spark-submit)
- Spark streaming from Kafka topic
- Reading from Postgres